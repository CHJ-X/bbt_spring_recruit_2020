#配置文件

db = {
    'host' : 'localhost',
    'user' : 'BBT', 
    'passwd' : '1693189780',
    'database' : 'spring_recruit_2020',
    'charset' : 'utf8mb4'
}

app = {
    'SECRET_KEY':'cnoaifh19484alsg&%&'#随机字符串
}